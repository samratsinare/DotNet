﻿using BindingDataBase.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BindingDataBase.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee
        public ActionResult Index()
        {

            List<Employee> list = new List<Employee>();


            SqlConnection sql = new SqlConnection();

            sql.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=JKDec20;Integrated Security=True;Pooling=False";

            sql.Open();

            SqlCommand cmd = new SqlCommand();

            cmd.Connection = sql;

            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "select * from Emp ";

            SqlDataReader dr = cmd.ExecuteReader();

            while(dr.Read())
            {

                list.Add(new Employee
                {
                    EmpNo = (int)dr["EmpId"],
                    EmpName = (string)dr["EmpName"],

                    Basic = (decimal)dr["EmpBasic"],
                    Address = (string)dr["Address"],
                    DeptNo = (int)dr["DeptNo"]
                }); 

            }

            sql.Close();

            return View(list);
        }

        // GET: Employee/Details/5
        public ActionResult Details(int id=0)
        {
            Employee emp = new Employee();

            SqlConnection sql = new SqlConnection();

            sql.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=JKDec20;Integrated Security=True;Pooling=False";

            sql.Open();

            SqlCommand cmd = new SqlCommand();

            cmd.Connection = sql;

            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "select * from Emp where EmpId = "+id;

            SqlDataReader dr = cmd.ExecuteReader();

            while(dr.Read())
            {

              emp.EmpNo = (int)dr["EmpId"];

              emp.EmpName = (string)(dr["EmpName"]);

              emp.Basic = (decimal)dr["EmpBasic"];

              emp.Address = (string)dr["Address"];

              emp.DeptNo = (int) dr["DeptNo"];

            }

            dr.Close();

            return View(emp);
        }

        // GET: Employee/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Employee/Create
        [HttpPost]
        public ActionResult Create(Employee empobject)
        {
            try
            {
                // TODO: Add insert logic here

                int empno = empobject.EmpNo;
                string name = empobject.EmpName;
                decimal basic = empobject.Basic;
                string add = empobject.Address;
                int deptno = empobject.DeptNo;

                SqlConnection sql = new SqlConnection();

                sql.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=JKDec20;Integrated Security=True;Pooling=False";

                sql.Open();

                SqlCommand cmd = new SqlCommand();

                cmd.Connection = sql;

                cmd.CommandType = CommandType.Text;

                cmd.CommandText = "insert into Emp values(@Empno,@EmpName,@EmpBasic,@Address,@Deptno)";

                cmd.Parameters.AddWithValue("@EmpNo", empno);
                cmd.Parameters.AddWithValue("@EmpName", name);
                cmd.Parameters.AddWithValue("@EmpBasic", basic);
                cmd.Parameters.AddWithValue("@Address", add);
                cmd.Parameters.AddWithValue("@DeptNo", deptno);
                

                int count = cmd.ExecuteNonQuery();

                sql.Close();


                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Employee/Edit/5
        public ActionResult Edit(int id=0)
        {
            Employee emp = new Employee();

            SqlConnection sql = new SqlConnection();

            sql.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=JKDec20;Integrated Security=True;Pooling=False";

            sql.Open();

            SqlCommand cmd = new SqlCommand();

            cmd.Connection = sql;

            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "select * from Emp where EmpId = " + id;

            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                emp.EmpNo = (int)dr["EmpId"];

                emp.EmpName = (string)(dr["EmpName"]);

                emp.Basic = (decimal)dr["EmpBasic"];

                emp.Address = (string)dr["Address"];

                emp.DeptNo = (int)dr["DeptNo"];

            }

            dr.Close();

            sql.Close();


            return View(emp);
        }

        // POST: Employee/Edit/5
        [HttpPost]
        public ActionResult Edit(int ? id, Employee objemp)
        {

            int empno = objemp.EmpNo;
            string name = objemp.EmpName;
            decimal basic = objemp.Basic;
            string add = objemp.Address;
            int deptno = objemp.DeptNo;

            //Employee emp = new Employee();

            SqlConnection sql = new SqlConnection();

            sql.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=JKDec20;Integrated Security=True;Pooling=False";

            sql.Open();

            try
            {
               
                SqlCommand cmd = new SqlCommand();

                cmd.Connection = sql;

                cmd.CommandType = CommandType.Text;

                cmd.CommandText = "update Emp set EmpName = @EmpName , EmpBasic = @EmpBasic , Address = @Address , DeptNo = @DeptNo where EmpId = @EmpNo";

              
                cmd.Parameters.AddWithValue("@EmpName", name);
                cmd.Parameters.AddWithValue("@EmpBasic", basic);
                cmd.Parameters.AddWithValue("@Address", add);
                cmd.Parameters.AddWithValue("@DeptNo", deptno);
                cmd.Parameters.AddWithValue("@EmpNo", empno);

                int count = cmd.ExecuteNonQuery();

                sql.Close();

                return RedirectToAction("Index");

                
            }
            catch
            {
                return View();
            }

            
        }

        // GET: Employee/Delete/5
        public ActionResult Delete(int id=0)
        {

            Employee emp = new Employee();

            SqlConnection sql = new SqlConnection();

            sql.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=JKDec20;Integrated Security=True;Pooling=False";

            sql.Open();

            SqlCommand cmd = new SqlCommand();

            cmd.Connection = sql;

            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "select * from Emp where EmpId = " + id;

            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                emp.EmpNo = (int)dr["EmpId"];

                emp.EmpName = (string)(dr["EmpName"]);

                emp.Basic = (decimal)dr["EmpBasic"];

                emp.Address = (string)dr["Address"];

                emp.DeptNo = (int)dr["DeptNo"];

            }

            dr.Close();

            return View(emp);
        }

        // POST: Employee/Delete/5
        [HttpPost]
        public ActionResult Delete(int ? id, Employee emp)
        {
            try
            {
                // TODO: Add delete logic here

                int empno = emp.EmpNo;
                string name = emp.EmpName;
                decimal basic = emp.Basic;
                string add = emp.Address;
                int deptno = emp.DeptNo;

                SqlConnection sql = new SqlConnection();

                sql.ConnectionString = @"Data Source=(localdb)\MsSqlLocalDb;Initial Catalog=JKDec20;Integrated Security=True;Pooling=False";

                sql.Open();

                SqlCommand cmd = new SqlCommand();

                cmd.Connection = sql;

                cmd.CommandType = CommandType.Text;

                cmd.CommandText = "delete from Emp where EmpId = @EmpNo";

                //SqlDataReader dr = cmd.ExecuteReader();

                cmd.Parameters.AddWithValue("@EmpNo", empno);

                int count = cmd.ExecuteNonQuery();

                sql.Close();

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
